# have a python dictionary key/value pair that represents a word and its a definition

from PyDictionary import PyDictionary

dictionary = PyDictionary("eyes", "goal", "rock")
print(dictionary.getMeanings())
print(dictionary.printMeanings())





#while True:
#    word = imput("Enter your word: ")
#    if word =="":
#        break

#    print(dictionary.meaning(word))


#def main():
 #   world_dictionary = {'hi': 'a way of greeting',
  #                      'eyes': 'an organ for seeing',
   #                     'earth': 'a planet in space',

    #}

    #while True:
     #   word = input("Enter a word: ")
     #   if word == "":
      #      break
       # if word in world_dictionary:
        #    print(word, ":", world_dictionary[word])