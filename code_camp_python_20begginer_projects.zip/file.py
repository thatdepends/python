test = 'rw*s/d*el*rvq*h%'

#you get in in gmail as 16 digit