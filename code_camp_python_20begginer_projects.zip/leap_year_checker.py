def is_leap_year(year):
    if year %4 == 0:
        if year % 100 == 0:
            if year %400== 0:
                print("Leap year")
            else:
                print("Not Leap yea")
 # pass pass is used for a future code to be written -  finish code, add code
        else:
            print('Leap year')
    else:
        print("Not Leap year.")

is_leap_year(2024)