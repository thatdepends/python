#run in python cl line by line

import requests
from bs4 import BeautifulSoup

url = 'https://www.codewithme.cl/'
r = requests.get(url)
r

soup = BeautifulSoup(r.content, 'lxml')
title = soup.find_all('h2',{'class':'post-title'})
title.getText()
title1 = title[0].getText()
print(title1)

for t  in title.getText:
    print(t.getText())

