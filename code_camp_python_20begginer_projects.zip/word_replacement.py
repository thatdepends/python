def replace_word():
    str = 'Hi, it seems dog dog dog dog still drinks water.'
    word_to_repleace = input("Enter the word to repleace: ")
    word_replacement = input("Enter the word repleacement: ")
    print(str.replace(word_to_repleace, word_replacement))

replace_word()