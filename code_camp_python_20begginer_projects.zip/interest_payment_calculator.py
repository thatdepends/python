# collect the necesarly inputs: principal, apr, years
# calculate monthly payment
# show that to the user

def main():
    print(" This is monthly payment loan calculator " + "/n/n/n/n")

    principal = float(input("Input the loan amount: "))
    apr = float(input("Input anual interest rate: "))
    years = int(input("Input amount of years: "))

    monthly_interests_rate = apr /1200
    amount_of_months = years * 12
    monthly_payment = principal * monthly_interests_rate / (1-(1 + monthly_interests_rate) ** (-amount_of_months))


    print(" The monthly payment for this loan is: %.2f " %  monthly_payment)

main()


