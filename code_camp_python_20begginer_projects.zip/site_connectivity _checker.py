# import urllib
# use urllib.request to get the data from url
# write a function that takes a url
# and reurns data from that url / return response

import urllib.request as urllib

def main(url):
    print("Checking conectivity ")

    response = urllib.urlopen(url)
    print("Connected to url ", url, "succesfully")
    print(f"The response code was ", {response.getcode()})



print("This is a site conectivity checkup program.")
input_url  = input ("Input the url of the site you want to check: ")

main(input_url)