# dictionary tbat stores Q and A
# have a variable that tracks the score of the pllaye
# loop trough the dictionary using the key value pairs
# display each q to the user and allow them to answer
# tell them if they are right or wrong
# show the final result when the quiz if completed

quiz = {
    "question1": {
        "question": "What is the capital of Spain?",
        "answer": "madrid"
    },
    "question2": {
        "question": "What is the capital of Italy?",
        "answer": "rome"
    },
    "question3": {
        "question": "What is the capital of Croatia?",
        "answer": "zagreb"
},
    "question4": {
        "question": "What is the capital of Slovenia?",
        "answer": "Ljubljana"
    },
}

score= 0

for key, value in quiz.items():
    print(value['question'])
    answer = input("Answer: ")

    if answer.lower() == value['answer'].lower():
        print("Correct")
        score+=1
        print("Your score is " + str(score))
        print("\n \n")

    else:
        print("Wrong")
        print("The answer is value" + value['answer'].lower())
        print("Your score is " + str(score))
        print("\n \n")

print("You got score " + str(score) + (" out of 4 questions."))
print("You procentage is " + str(int(score/4 * 100)) + "%")
