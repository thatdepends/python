name = input("Type your name: ")
print("Wellcome ", name, "to this adventure")

answer = input("You are on a dirt road, it has come to an end you can go left or right. Which way would you like to go? ").lower()

if answer == "left":
    answer = input("You came to a river. You can walk around it or swim accross? Type walk to walk arround or swim to swim accross: ")

    if answer=="swim":
        print("You swam accross and were eaten by an aligator.")
    elif answer=="walk":
        print("You walked for many miles, ran out of water and you lost a game.")
    else:
        print('Not a valid option. You lose.')

elif answer== "right":
    answer= input("You came to a bridge, it looks woobly, do you want to cross it or head back (cross/back? ")

    if answer=="cross":
        print("You go back and lose .")
    elif answer=="back":
        answer = input("You crossed the bridge and meet the stranger. Do you talk to them ? (Yes/No)")

        if answer == "yes":
            print("You talked to the stranger. You win")
        elif answer == "no":
            print("You ignored the stranger. You lose")
        else:
            print('Not a valid option. You lose.')
else:
    print('Not a valid option. You lose.')

print("Thank you for trying ", name)

