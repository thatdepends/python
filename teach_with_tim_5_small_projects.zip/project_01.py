print("Welcome to my computer quiz!")
playing = input("Do you want to play? ")
if playing.lower() != "yes":
    quit()
print("Ok, Lets play :) :)")
score = 0

answer = input("What does CPU stand for? ")
if answer.lower() == "central processing unit":
    print("Correct!")
    score +=1
else:
    print("Incorect!")

answer = input("What does GPU atand for? ")
if answer.lower() == "graphics processing unit":
    print("Correct!")
    score+=1
else:
    print("Incorect!")

answer = input("What does RAM stand for? ")
if answer.lower() == "random access memory":
    print("Correct!")
    score+=1
else:
    print("Incorect!")

answer = input("What dows PSU stand for? ")
if answer.lower() == "power supply":
    print("Correct!")
    score+=1
else:
    print("Incorect!")

print("You got " + str(score) + " question correct")
print("You got " + str((score / 4 )*100) + "%.")